from analyze_trans_sim import *
import pymc3 as pm
import theano as T
import theano.tensor as tt

def model(sim_data, prior_data):

    mod = pm.Model()
    with mod:
        #probailities of each primitive
        probs = pm.Dirichlet("probs", np.ones(N_PRIM))

        #copy the probability vector a number of times
        #so that it becomes a tensor
        #ith that the probabilities of each primtive
        #for each hypothesis
        probs = tt.tile(probs, (N_TOP, 1))
        probs = tt.tile(probs, (N_PAIRS, 1,1))     

        #and now convert the probabilities assigned 
        #to each hypothesis for a given sequence pair
        #into entropy
        ents = tt.pow(probs, prior_data)
        ents = tt.log(ents)
        x1 = tt.sum(ents,axis=2)
        x2 = tt.exp(x1)
        ents = x1 * x2
        ents = tt.sum(ents, axis=1)
        ents = -1.0 * ents
        mean_pr = tt.mean(ents)
        std_pr = tt.std(ents)
        ents = (ents - mean_pr)/std_pr
        ents = ents[assigns]


        #intercept
        alpha = pm.Normal('alpha', mu=0, sd=10)
        #slope
        beta = pm.Normal('beta', mu=0, sd=10)
        #standard deviation
        sigma = pm.HalfNormal('sigma', sd=1)
        #expected value of similarity 
        mu = alpha + beta*ents

        #compare fit to observed similarity data
        Y_obs = pm.Normal('Y_obs', mu=mu, sd=sigma, observed=sim_data_lst)


        trace = pm.sample(MCMC_STEPS,
            tune=BURNIN,target_accept=0.9, thin=MCMC_THIN)

    map_estimate = pm.find_MAP(model=mod)

    print map_estimate

if __name__ == "__main__":
    #globals
    MCMC_STEPS = 50
    BURNIN=10
    MCMC_THIN = 1

    #similarity data from experiment
    sim_data =  get_sim_data("out_sim_only.csv")
    #priors on transformations (and each primitive in hypothesis)
    #from LOT model
    prior_data = get_trans_data_by_prim("out_priors.csv")

    #turn both into lists (from dictionaries)
    sim_data_lst =[]
    prior_data_lst = []
    for k in prior_data.keys():
        prior_data_lst.append(copy.deepcopy(prior_data[k]))
        if k in sim_data:
            sim_data_lst.append(copy.deepcopy(sim_data[k]))
        else:
            sim_data_lst.append(copy.deepcopy(sim_data[(k[1], k[0])]))


    #number of sequence pairs
    N_PAIRS = len(prior_data_lst)
    #number of participants responding per sequence pair
    N_PER_PAIR = [len(x) for x in sim_data_lst]
    #number of top transformation
    #hypotheses recorded per sequence pair
    N_TOP = len(prior_data_lst[0])
    #number of primitives in model
    N_PRIM = len(prior_data_lst[0][0])

    assigns= []
    for i in xrange(len(N_PER_PAIR)):
        a = [i for _ in xrange(N_PER_PAIR[i])]
        assigns.append(a)

    #this is used to flatten the array of
    #hypotheses, mapping it to each sequence pair 
    #for each participant responding to that 
    #sequence pair
    assigns = np.concatenate(assigns)


    prior_data_lst = np.array(prior_data_lst) 
    sim_data_lst = np.array(sim_data_lst)


    prior_data_lst_assign = prior_data_lst[assigns]

    #flatten similarity data
    sim_data_lst = np.sum(sim_data_lst)

    model(sim_data_lst, prior_data_lst)
